<?php
include '../DAO.php';

$FIRSTNAME = $_POST['firstname'];
$LASTNAME = $_POST['lastname'];
$PASSWORD = $_POST['password'];

$save = mysqli_query($con, "INSERT INTO users VALUES (null,'$FIRSTNAME','$LASTNAME','$LASTNAME','$PASSWORD',now()) ")or die(mysqli_error($con));
if($save){
    header("location:../password_reset.php");
}
else{
    header("location:../register.php");
}
   


?>