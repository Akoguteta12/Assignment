<?php
require '../DAO.php';

$USERNAME = $_POST['username'];
$PASSWORD = $_POST['password'];

$login = mysqli_query($con,"SELECT * FROM users WHERE username='$USERNAME' and password='$PASSWORD'");
$count = mysqli_num_rows($login);
if ($count>0) {
    header("location:../password_reset.php");
//    echo "<script>alert('Welcome');window.location='../password_reset.php';</script>";
}
else{
    // echo "<script>alert('Unauthorized user');window.location='../index.php';</script>";
  header("location:../index.php");
}

?>